package br.cefetmg.guitar_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuitarStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuitarStoreApplication.class, args);
	}

}
